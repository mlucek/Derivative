#pragma once
#include "Reader.h"
class Arcsin :
	public Reader
{
public:
	std::string counter(std::string exp);
};

