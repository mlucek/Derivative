#pragma once
#include "Reader.h"
class Ctg :
	public Reader
{
public:
	std::string counter(std::string exp);
};

