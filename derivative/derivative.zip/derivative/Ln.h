#pragma once
#include "Reader.h"
class Ln :
	public Reader
{
public:
	std::string counter(std::string exp);
};

