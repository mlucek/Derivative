#pragma once
#include "Reader.h"
class Cos :
	public Reader
{
public:
	std::string counter(std::string exp);
};

