#pragma once
#include "Reader.h"
class Arcctg :
	public Reader
{
public:
	std::string counter(std::string exp);
};

