#pragma once
#include "Reader.h"
class Tg :
	public Reader
{
public:
	std::string counter(std::string exp);
};

