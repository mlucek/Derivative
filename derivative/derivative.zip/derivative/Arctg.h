#pragma once
#include "Reader.h"
class Arctg :
	public Reader
{
public:
	std::string counter(std::string exp);
};

