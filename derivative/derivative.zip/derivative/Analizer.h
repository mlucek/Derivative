#pragma once
#include"Sin.h"
class Analizer
{
public:
	
	
};

