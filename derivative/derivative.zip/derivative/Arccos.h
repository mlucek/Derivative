#pragma once
#include "Reader.h"
class Arccos :
	public Reader
{
public:
	std::string counter(std::string exp);
};

